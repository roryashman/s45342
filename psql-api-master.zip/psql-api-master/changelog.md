# Changes



* 18 Oct 2015
bug in "CRUD batch operations" solved - Insert/Create

* 17 Oct 2015
Changes Log - opened


